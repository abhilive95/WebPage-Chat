

var botui = new BotUI('hello-world');
//botui.message.removeall();
botui.message
    .add({
      content : 'Hi, I am Bot, your Personal Assistant. I can try to help you in getting answer to your queries related to CenturyLink.'
    });
$(document).ready(function() {
  $('#question').keydown(function(e) {
    if (e.keyCode == 13) {
      var question = $('#question').val();
      document.getElementById('question').value = "";
      botui.message.add({
        human : true,
        content : question
      });
      $.ajax({
        url : "http://192.168.0.10:8080/pythonexecutor",
        type : "POST",
        data : question,
        contentType : "application/text; charset=utf-8",
        dataType : "text",
        crossOrigin : null,
        success : function(response) {
          botui.message.add({
            content : response
          });
        },
        failure : function(errMsg) {
          alert("Error");
        }
      });
    }
  }); //Key down ends here
});
function openForm() {
  document.getElementById("myForm").style.display = "block";
}
function minimizeForm() {
  document.getElementById("myForm").style.display = "none";
}
function closeForm() {
    botui.message.removeAll();
  botui.message
  botui.message.add({
      content : 'Hi, I am Bot, your Personal Assistant. I can try to help you in getting answer to your queries related to CenturyLink.'
    });
  document.getElementById("myForm").style.display = "none";

}
